<?php

include("../conectarbd.php");

$recid= filter_input(INPUT_GET, 'reunioes');



  if(mysqli_query($conn, "DELETE FROM tb_reunioes WHERE id_reunioes=$recid")) {

    echo "<script>alert('Dados excluidos com sucesso!'); window.location = 'FormConsultarReuniao.php';</script>";

  }else {

    echo "Não foi possível excluir os dados no Banco de Dados" . $recid . "<br>" . mysqli_error($conn);

  }

  mysqli_close($conn);



?>